package net.avantage.api.assignements;

public class Payload {

    public static String assignmentBody(){

        return "{\n" +
                "        \"userId\": 5,\n" +
                "        \"title\": \"Milan\",\n" +
                "        \"body\": \"Is the Best\"\n" +
                "}";
    }

    }
