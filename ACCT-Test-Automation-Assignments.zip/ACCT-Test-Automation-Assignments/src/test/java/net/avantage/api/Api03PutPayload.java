package net.avantage.api;

public class Api03PutPayload {
    public static String assignment3RequestBody(){
        return "{\n" +
                "    \"title\": \"UpdatedTitle\",\n" +
                "    \"body\": \"UpdatedBody\",\n" +
                "    \"userId\": 11,\n" +
                "    \"id\": 1\n" +
                "}";
    }
}
